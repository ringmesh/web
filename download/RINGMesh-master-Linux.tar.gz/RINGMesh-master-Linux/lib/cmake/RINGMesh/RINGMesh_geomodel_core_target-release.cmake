#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::geomodel_core" for configuration "Release"
set_property(TARGET RINGMesh::geomodel_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(RINGMesh::geomodel_core PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libRINGMesh_geomodel_core.so"
  IMPORTED_SONAME_RELEASE "libRINGMesh_geomodel_core.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::geomodel_core )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::geomodel_core "${_IMPORT_PREFIX}/lib/libRINGMesh_geomodel_core.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
