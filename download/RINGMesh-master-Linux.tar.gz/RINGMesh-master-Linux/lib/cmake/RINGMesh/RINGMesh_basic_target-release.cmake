#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::basic" for configuration "Release"
set_property(TARGET RINGMesh::basic APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(RINGMesh::basic PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libRINGMesh_basic.so"
  IMPORTED_SONAME_RELEASE "libRINGMesh_basic.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::basic )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::basic "${_IMPORT_PREFIX}/lib/libRINGMesh_basic.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
