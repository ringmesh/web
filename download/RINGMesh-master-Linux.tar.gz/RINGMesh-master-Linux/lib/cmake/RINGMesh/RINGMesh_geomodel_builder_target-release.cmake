#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::geomodel_builder" for configuration "Release"
set_property(TARGET RINGMesh::geomodel_builder APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(RINGMesh::geomodel_builder PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "tinyxml2"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libRINGMesh_geomodel_builder.so"
  IMPORTED_SONAME_RELEASE "libRINGMesh_geomodel_builder.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::geomodel_builder )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::geomodel_builder "${_IMPORT_PREFIX}/lib/libRINGMesh_geomodel_builder.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
