#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::visualize" for configuration "Release"
set_property(TARGET RINGMesh::visualize APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(RINGMesh::visualize PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libRINGMesh_visualize.so"
  IMPORTED_SONAME_RELEASE "libRINGMesh_visualize.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::visualize )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::visualize "${_IMPORT_PREFIX}/lib/libRINGMesh_visualize.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
