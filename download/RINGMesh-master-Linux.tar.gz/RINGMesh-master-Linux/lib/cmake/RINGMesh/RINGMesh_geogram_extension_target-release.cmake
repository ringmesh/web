#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::geogram_extension" for configuration "Release"
set_property(TARGET RINGMesh::geogram_extension APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(RINGMesh::geogram_extension PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libRINGMesh_geogram_extension.so"
  IMPORTED_SONAME_RELEASE "libRINGMesh_geogram_extension.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::geogram_extension )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::geogram_extension "${_IMPORT_PREFIX}/lib/libRINGMesh_geogram_extension.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
