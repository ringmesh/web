#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::io" for configuration "Release"
set_property(TARGET RINGMesh::io APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(RINGMesh::io PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELEASE "tinyxml2"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libRINGMesh_io.so"
  IMPORTED_SONAME_RELEASE "libRINGMesh_io.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::io )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::io "${_IMPORT_PREFIX}/lib/libRINGMesh_io.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
