
#ifndef basic_api_H
#define basic_api_H

#ifdef BASIC_STATIC_DEFINE
#  define basic_api
#  define BASIC_NO_EXPORT
#else
#  ifndef basic_api
#    ifdef basic_EXPORTS
        /* We are building this library */
#      define basic_api __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define basic_api __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef BASIC_NO_EXPORT
#    define BASIC_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef BASIC_DEPRECATED
#  define BASIC_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef BASIC_DEPRECATED_EXPORT
#  define BASIC_DEPRECATED_EXPORT basic_api BASIC_DEPRECATED
#endif

#ifndef BASIC_DEPRECATED_NO_EXPORT
#  define BASIC_DEPRECATED_NO_EXPORT BASIC_NO_EXPORT BASIC_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef BASIC_NO_DEPRECATED
#    define BASIC_NO_DEPRECATED
#  endif
#endif

#endif /* basic_api_H */
