
#ifndef visualize_api_H
#define visualize_api_H

#ifdef VISUALIZE_STATIC_DEFINE
#  define visualize_api
#  define VISUALIZE_NO_EXPORT
#else
#  ifndef visualize_api
#    ifdef visualize_EXPORTS
        /* We are building this library */
#      define visualize_api __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define visualize_api __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef VISUALIZE_NO_EXPORT
#    define VISUALIZE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef VISUALIZE_DEPRECATED
#  define VISUALIZE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef VISUALIZE_DEPRECATED_EXPORT
#  define VISUALIZE_DEPRECATED_EXPORT visualize_api VISUALIZE_DEPRECATED
#endif

#ifndef VISUALIZE_DEPRECATED_NO_EXPORT
#  define VISUALIZE_DEPRECATED_NO_EXPORT VISUALIZE_NO_EXPORT VISUALIZE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef VISUALIZE_NO_DEPRECATED
#    define VISUALIZE_NO_DEPRECATED
#  endif
#endif

#endif
