
#ifndef tetrahedralize_api_H
#define tetrahedralize_api_H

#ifdef TETRAHEDRALIZE_STATIC_DEFINE
#  define tetrahedralize_api
#  define TETRAHEDRALIZE_NO_EXPORT
#else
#  ifndef tetrahedralize_api
#    ifdef tetrahedralize_EXPORTS
        /* We are building this library */
#      define tetrahedralize_api __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define tetrahedralize_api __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef TETRAHEDRALIZE_NO_EXPORT
#    define TETRAHEDRALIZE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef TETRAHEDRALIZE_DEPRECATED
#  define TETRAHEDRALIZE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef TETRAHEDRALIZE_DEPRECATED_EXPORT
#  define TETRAHEDRALIZE_DEPRECATED_EXPORT tetrahedralize_api TETRAHEDRALIZE_DEPRECATED
#endif

#ifndef TETRAHEDRALIZE_DEPRECATED_NO_EXPORT
#  define TETRAHEDRALIZE_DEPRECATED_NO_EXPORT TETRAHEDRALIZE_NO_EXPORT TETRAHEDRALIZE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef TETRAHEDRALIZE_NO_DEPRECATED
#    define TETRAHEDRALIZE_NO_DEPRECATED
#  endif
#endif

#endif
