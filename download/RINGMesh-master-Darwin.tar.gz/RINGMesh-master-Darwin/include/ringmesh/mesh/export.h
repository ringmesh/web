
#ifndef mesh_api_H
#define mesh_api_H

#ifdef MESH_STATIC_DEFINE
#  define mesh_api
#  define MESH_NO_EXPORT
#else
#  ifndef mesh_api
#    ifdef mesh_EXPORTS
        /* We are building this library */
#      define mesh_api __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define mesh_api __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef MESH_NO_EXPORT
#    define MESH_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef MESH_DEPRECATED
#  define MESH_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef MESH_DEPRECATED_EXPORT
#  define MESH_DEPRECATED_EXPORT mesh_api MESH_DEPRECATED
#endif

#ifndef MESH_DEPRECATED_NO_EXPORT
#  define MESH_DEPRECATED_NO_EXPORT MESH_NO_EXPORT MESH_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MESH_NO_DEPRECATED
#    define MESH_NO_DEPRECATED
#  endif
#endif

#endif /* mesh_api_H */
