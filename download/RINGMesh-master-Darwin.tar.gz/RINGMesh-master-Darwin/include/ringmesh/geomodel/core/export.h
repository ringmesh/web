
#ifndef geomodel_core_api_H
#define geomodel_core_api_H

#ifdef GEOMODEL_CORE_STATIC_DEFINE
#  define geomodel_core_api
#  define GEOMODEL_CORE_NO_EXPORT
#else
#  ifndef geomodel_core_api
#    ifdef geomodel_core_EXPORTS
        /* We are building this library */
#      define geomodel_core_api __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define geomodel_core_api __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GEOMODEL_CORE_NO_EXPORT
#    define GEOMODEL_CORE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GEOMODEL_CORE_DEPRECATED
#  define GEOMODEL_CORE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef GEOMODEL_CORE_DEPRECATED_EXPORT
#  define GEOMODEL_CORE_DEPRECATED_EXPORT geomodel_core_api GEOMODEL_CORE_DEPRECATED
#endif

#ifndef GEOMODEL_CORE_DEPRECATED_NO_EXPORT
#  define GEOMODEL_CORE_DEPRECATED_NO_EXPORT GEOMODEL_CORE_NO_EXPORT GEOMODEL_CORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef GEOMODEL_CORE_NO_DEPRECATED
#    define GEOMODEL_CORE_NO_DEPRECATED
#  endif
#endif

#endif /* geomodel_core_api_H */
