
#ifndef geomodel_tools_api_H
#define geomodel_tools_api_H

#ifdef GEOMODEL_TOOLS_STATIC_DEFINE
#  define geomodel_tools_api
#  define GEOMODEL_TOOLS_NO_EXPORT
#else
#  ifndef geomodel_tools_api
#    ifdef geomodel_tools_EXPORTS
        /* We are building this library */
#      define geomodel_tools_api __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define geomodel_tools_api __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GEOMODEL_TOOLS_NO_EXPORT
#    define GEOMODEL_TOOLS_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GEOMODEL_TOOLS_DEPRECATED
#  define GEOMODEL_TOOLS_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef GEOMODEL_TOOLS_DEPRECATED_EXPORT
#  define GEOMODEL_TOOLS_DEPRECATED_EXPORT geomodel_tools_api GEOMODEL_TOOLS_DEPRECATED
#endif

#ifndef GEOMODEL_TOOLS_DEPRECATED_NO_EXPORT
#  define GEOMODEL_TOOLS_DEPRECATED_NO_EXPORT GEOMODEL_TOOLS_NO_EXPORT GEOMODEL_TOOLS_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef GEOMODEL_TOOLS_NO_DEPRECATED
#    define GEOMODEL_TOOLS_NO_DEPRECATED
#  endif
#endif

#endif /* geomodel_tools_api_H */
