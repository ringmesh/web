#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::mesh" for configuration "Release"
set_property(TARGET RINGMesh::mesh APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(RINGMesh::mesh PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libRINGMesh_mesh.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libRINGMesh_mesh.dylib"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::mesh )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::mesh "${_IMPORT_PREFIX}/lib/libRINGMesh_mesh.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
