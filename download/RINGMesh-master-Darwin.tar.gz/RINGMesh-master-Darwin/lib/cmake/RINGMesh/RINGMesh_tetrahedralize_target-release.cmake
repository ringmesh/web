#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::tetrahedralize" for configuration "Release"
set_property(TARGET RINGMesh::tetrahedralize APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(RINGMesh::tetrahedralize PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libRINGMesh_tetrahedralize.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libRINGMesh_tetrahedralize.dylib"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::tetrahedralize )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::tetrahedralize "${_IMPORT_PREFIX}/lib/libRINGMesh_tetrahedralize.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
