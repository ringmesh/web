#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::geomodel_builder" for configuration "RelWithDebInfo"
set_property(TARGET RINGMesh::geomodel_builder APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RINGMesh::geomodel_builder PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/RINGMesh_geomodel_builder.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "tinyxml2"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/RINGMesh_geomodel_builder.dll"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::geomodel_builder )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::geomodel_builder "${_IMPORT_PREFIX}/lib/RINGMesh_geomodel_builder.lib" "${_IMPORT_PREFIX}/bin/RINGMesh_geomodel_builder.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
