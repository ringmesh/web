#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::geomodel_tools" for configuration "RelWithDebInfo"
set_property(TARGET RINGMesh::geomodel_tools APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RINGMesh::geomodel_tools PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/RINGMesh_geomodel_tools.lib"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/RINGMesh_geomodel_tools.dll"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::geomodel_tools )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::geomodel_tools "${_IMPORT_PREFIX}/lib/RINGMesh_geomodel_tools.lib" "${_IMPORT_PREFIX}/bin/RINGMesh_geomodel_tools.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
