#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::io" for configuration "RelWithDebInfo"
set_property(TARGET RINGMesh::io APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RINGMesh::io PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/RINGMesh_io.lib"
  IMPORTED_LINK_DEPENDENT_LIBRARIES_RELWITHDEBINFO "tinyxml2"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/RINGMesh_io.dll"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::io )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::io "${_IMPORT_PREFIX}/lib/RINGMesh_io.lib" "${_IMPORT_PREFIX}/bin/RINGMesh_io.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
