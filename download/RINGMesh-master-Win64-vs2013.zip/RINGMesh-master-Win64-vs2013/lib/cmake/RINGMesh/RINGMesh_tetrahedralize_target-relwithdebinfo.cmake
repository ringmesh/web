#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::tetrahedralize" for configuration "RelWithDebInfo"
set_property(TARGET RINGMesh::tetrahedralize APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RINGMesh::tetrahedralize PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/RINGMesh_tetrahedralize.lib"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/RINGMesh_tetrahedralize.dll"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::tetrahedralize )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::tetrahedralize "${_IMPORT_PREFIX}/lib/RINGMesh_tetrahedralize.lib" "${_IMPORT_PREFIX}/bin/RINGMesh_tetrahedralize.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
