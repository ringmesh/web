#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::visualize" for configuration "RelWithDebInfo"
set_property(TARGET RINGMesh::visualize APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RINGMesh::visualize PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/RINGMesh_visualize.lib"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/RINGMesh_visualize.dll"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::visualize )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::visualize "${_IMPORT_PREFIX}/lib/RINGMesh_visualize.lib" "${_IMPORT_PREFIX}/bin/RINGMesh_visualize.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
