# Copyright (c) 2012-2018, Association Scientifique pour la Geologie et ses
# Applications (ASGA). All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#     * Redistributions in binary form must reproduce the above copyright
#       notice, this list of conditions and the following disclaimer in the
#       documentation and/or other materials provided with the distribution.
#     * Neither the name of ASGA nor the
#       names of its contributors may be used to endorse or promote products
#       derived from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
# PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ASGA BE LIABLE FOR ANY DIRECT,
# INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#     http://www.ring-team.org
#
#     RING Project
#     Ecole Nationale Superieure de Geologie - GeoRessources
#     2 Rue du Doyen Marcel Roubault - TSA 70605
#     54518 VANDOEUVRE-LES-NANCY
#     FRANCE
#


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was RINGMeshConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

#################################################################################### 

if(EXISTS ${PACKAGE_PREFIX_DIR}/lib/cmake/modules/FindGeogram.cmake)
    # Install/Package configuration
    set_and_check(GEOGRAM_INSTALL_PREFIX ${PACKAGE_PREFIX_DIR})
else()
    # Build tree configuration
    set_and_check(GEOGRAM_INSTALL_PREFIX C:/projects/ringmesh/build/third_party/geogram/install)
endif()
list(APPEND CMAKE_MODULE_PATH ${GEOGRAM_INSTALL_PREFIX}/lib/cmake/modules)
set(VORPALINE_BUILD_DYNAMIC TRUE CACHE BOOL "")
find_package(Geogram REQUIRED)

# Load information for each target.
include(${CMAKE_CURRENT_LIST_DIR}/RINGMesh_basic_target.cmake)
include(${CMAKE_CURRENT_LIST_DIR}/RINGMesh_mesh_target.cmake)
include(${CMAKE_CURRENT_LIST_DIR}/RINGMesh_geogram_extension_target.cmake)
include(${CMAKE_CURRENT_LIST_DIR}/RINGMesh_geomodel_core_target.cmake)
include(${CMAKE_CURRENT_LIST_DIR}/RINGMesh_geomodel_builder_target.cmake)
include(${CMAKE_CURRENT_LIST_DIR}/RINGMesh_tetrahedralize_target.cmake)
include(${CMAKE_CURRENT_LIST_DIR}/RINGMesh_geomodel_tools_target.cmake)
include(${CMAKE_CURRENT_LIST_DIR}/RINGMesh_io_target.cmake)

if(EXISTS ${CMAKE_CURRENT_LIST_DIR}/RINGMesh_visualize_target.cmake)
	include(${CMAKE_CURRENT_LIST_DIR}/RINGMesh_visualize_target.cmake)
endif()
