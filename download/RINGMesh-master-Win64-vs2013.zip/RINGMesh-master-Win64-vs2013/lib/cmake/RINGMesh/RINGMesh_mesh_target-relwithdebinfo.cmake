#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::mesh" for configuration "RelWithDebInfo"
set_property(TARGET RINGMesh::mesh APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RINGMesh::mesh PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/RINGMesh_mesh.lib"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/RINGMesh_mesh.dll"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::mesh )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::mesh "${_IMPORT_PREFIX}/lib/RINGMesh_mesh.lib" "${_IMPORT_PREFIX}/bin/RINGMesh_mesh.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
