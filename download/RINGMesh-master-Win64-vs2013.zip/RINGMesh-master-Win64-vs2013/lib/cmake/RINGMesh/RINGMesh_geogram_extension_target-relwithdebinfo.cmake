#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::geogram_extension" for configuration "RelWithDebInfo"
set_property(TARGET RINGMesh::geogram_extension APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RINGMesh::geogram_extension PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/RINGMesh_geogram_extension.lib"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/RINGMesh_geogram_extension.dll"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::geogram_extension )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::geogram_extension "${_IMPORT_PREFIX}/lib/RINGMesh_geogram_extension.lib" "${_IMPORT_PREFIX}/bin/RINGMesh_geogram_extension.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
