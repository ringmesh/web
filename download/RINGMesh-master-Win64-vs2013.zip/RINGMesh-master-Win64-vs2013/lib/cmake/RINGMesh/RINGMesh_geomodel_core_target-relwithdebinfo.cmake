#----------------------------------------------------------------
# Generated CMake target import file for configuration "RelWithDebInfo".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "RINGMesh::geomodel_core" for configuration "RelWithDebInfo"
set_property(TARGET RINGMesh::geomodel_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELWITHDEBINFO)
set_target_properties(RINGMesh::geomodel_core PROPERTIES
  IMPORTED_IMPLIB_RELWITHDEBINFO "${_IMPORT_PREFIX}/lib/RINGMesh_geomodel_core.lib"
  IMPORTED_LOCATION_RELWITHDEBINFO "${_IMPORT_PREFIX}/bin/RINGMesh_geomodel_core.dll"
  )

list(APPEND _IMPORT_CHECK_TARGETS RINGMesh::geomodel_core )
list(APPEND _IMPORT_CHECK_FILES_FOR_RINGMesh::geomodel_core "${_IMPORT_PREFIX}/lib/RINGMesh_geomodel_core.lib" "${_IMPORT_PREFIX}/bin/RINGMesh_geomodel_core.dll" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
