
#ifndef io_api_H
#define io_api_H

#ifdef IO_STATIC_DEFINE
#  define io_api
#  define IO_NO_EXPORT
#else
#  ifndef io_api
#    ifdef io_EXPORTS
        /* We are building this library */
#      define io_api __declspec(dllexport)
#    else
        /* We are using this library */
#      define io_api __declspec(dllimport)
#    endif
#  endif

#  ifndef IO_NO_EXPORT
#    define IO_NO_EXPORT 
#  endif
#endif

#ifndef IO_DEPRECATED
#  define IO_DEPRECATED __declspec(deprecated)
#endif

#ifndef IO_DEPRECATED_EXPORT
#  define IO_DEPRECATED_EXPORT io_api IO_DEPRECATED
#endif

#ifndef IO_DEPRECATED_NO_EXPORT
#  define IO_DEPRECATED_NO_EXPORT IO_NO_EXPORT IO_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef IO_NO_DEPRECATED
#    define IO_NO_DEPRECATED
#  endif
#endif

#endif
