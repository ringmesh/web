
#ifndef geogram_extension_api_H
#define geogram_extension_api_H

#ifdef GEOGRAM_EXTENSION_STATIC_DEFINE
#  define geogram_extension_api
#  define GEOGRAM_EXTENSION_NO_EXPORT
#else
#  ifndef geogram_extension_api
#    ifdef geogram_extension_EXPORTS
        /* We are building this library */
#      define geogram_extension_api __declspec(dllexport)
#    else
        /* We are using this library */
#      define geogram_extension_api __declspec(dllimport)
#    endif
#  endif

#  ifndef GEOGRAM_EXTENSION_NO_EXPORT
#    define GEOGRAM_EXTENSION_NO_EXPORT 
#  endif
#endif

#ifndef GEOGRAM_EXTENSION_DEPRECATED
#  define GEOGRAM_EXTENSION_DEPRECATED __declspec(deprecated)
#endif

#ifndef GEOGRAM_EXTENSION_DEPRECATED_EXPORT
#  define GEOGRAM_EXTENSION_DEPRECATED_EXPORT geogram_extension_api GEOGRAM_EXTENSION_DEPRECATED
#endif

#ifndef GEOGRAM_EXTENSION_DEPRECATED_NO_EXPORT
#  define GEOGRAM_EXTENSION_DEPRECATED_NO_EXPORT GEOGRAM_EXTENSION_NO_EXPORT GEOGRAM_EXTENSION_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef GEOGRAM_EXTENSION_NO_DEPRECATED
#    define GEOGRAM_EXTENSION_NO_DEPRECATED
#  endif
#endif

#endif
