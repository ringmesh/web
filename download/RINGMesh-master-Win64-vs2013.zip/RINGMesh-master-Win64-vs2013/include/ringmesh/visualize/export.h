
#ifndef visualize_api_H
#define visualize_api_H

#ifdef VISUALIZE_STATIC_DEFINE
#  define visualize_api
#  define VISUALIZE_NO_EXPORT
#else
#  ifndef visualize_api
#    ifdef visualize_EXPORTS
        /* We are building this library */
#      define visualize_api __declspec(dllexport)
#    else
        /* We are using this library */
#      define visualize_api __declspec(dllimport)
#    endif
#  endif

#  ifndef VISUALIZE_NO_EXPORT
#    define VISUALIZE_NO_EXPORT 
#  endif
#endif

#ifndef VISUALIZE_DEPRECATED
#  define VISUALIZE_DEPRECATED __declspec(deprecated)
#endif

#ifndef VISUALIZE_DEPRECATED_EXPORT
#  define VISUALIZE_DEPRECATED_EXPORT visualize_api VISUALIZE_DEPRECATED
#endif

#ifndef VISUALIZE_DEPRECATED_NO_EXPORT
#  define VISUALIZE_DEPRECATED_NO_EXPORT VISUALIZE_NO_EXPORT VISUALIZE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef VISUALIZE_NO_DEPRECATED
#    define VISUALIZE_NO_DEPRECATED
#  endif
#endif

#endif
