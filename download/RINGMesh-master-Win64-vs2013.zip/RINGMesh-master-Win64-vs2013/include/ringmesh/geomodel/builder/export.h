
#ifndef geomodel_builder_api_H
#define geomodel_builder_api_H

#ifdef GEOMODEL_BUILDER_STATIC_DEFINE
#  define geomodel_builder_api
#  define GEOMODEL_BUILDER_NO_EXPORT
#else
#  ifndef geomodel_builder_api
#    ifdef geomodel_builder_EXPORTS
        /* We are building this library */
#      define geomodel_builder_api __declspec(dllexport)
#    else
        /* We are using this library */
#      define geomodel_builder_api __declspec(dllimport)
#    endif
#  endif

#  ifndef GEOMODEL_BUILDER_NO_EXPORT
#    define GEOMODEL_BUILDER_NO_EXPORT 
#  endif
#endif

#ifndef GEOMODEL_BUILDER_DEPRECATED
#  define GEOMODEL_BUILDER_DEPRECATED __declspec(deprecated)
#endif

#ifndef GEOMODEL_BUILDER_DEPRECATED_EXPORT
#  define GEOMODEL_BUILDER_DEPRECATED_EXPORT geomodel_builder_api GEOMODEL_BUILDER_DEPRECATED
#endif

#ifndef GEOMODEL_BUILDER_DEPRECATED_NO_EXPORT
#  define GEOMODEL_BUILDER_DEPRECATED_NO_EXPORT GEOMODEL_BUILDER_NO_EXPORT GEOMODEL_BUILDER_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef GEOMODEL_BUILDER_NO_DEPRECATED
#    define GEOMODEL_BUILDER_NO_DEPRECATED
#  endif
#endif

#endif
