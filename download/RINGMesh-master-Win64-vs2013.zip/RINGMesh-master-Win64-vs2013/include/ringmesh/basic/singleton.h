/*
 * Copyright (c) 2012-2018, Association Scientifique pour la Geologie et ses
 * Applications (ASGA). All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of ASGA nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL ASGA BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *     http://www.ring-team.org
 *
 *     RING Project
 *     Ecole Nationale Superieure de Geologie - GeoRessources
 *     2 Rue du Doyen Marcel Roubault - TSA 70605
 *     54518 VANDOEUVRE-LES-NANCY
 *     FRANCE
 */

#pragma once

#include <ringmesh/basic/common.h>

/*!
 * @file  Singleton class
 * @author Arnaud Botella
 */

namespace RINGMesh
{
    /*!
     * \brief Cross platform singleton implementation
     * \details Classic templated singleton cannot be exported on Windows.
     *  To ensure a unique instance of the singleton, we store it and
     *  export methods to retrieve the unique instance.
     *
     *  To use this class, inherit from it and use the protected
     *  method Singleton::instance().
     */
    class basic_api Singleton
    {
        ringmesh_disable_copy_and_move( Singleton );

    public:
        virtual ~Singleton() = default;

    protected:
        Singleton() = default;

        template < class SingletonType >
        static SingletonType& instance()
        {
            auto singleton = dynamic_cast< SingletonType* >(
                instance( typeid( SingletonType ) ) );
            if( singleton == nullptr )
            {
                singleton = new SingletonType{};
                set_instance( typeid( SingletonType ), singleton );
            }

            return *singleton;
        }

    private:
        static void set_instance(
            const std::type_info& type, Singleton* singleton );
        static Singleton* instance( const std::type_info& type );
    };

} // namespace RINGMesh
