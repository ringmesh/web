
#ifndef geomodel_core_api_H
#define geomodel_core_api_H

#ifdef GEOMODEL_CORE_STATIC_DEFINE
#  define geomodel_core_api
#  define GEOMODEL_CORE_NO_EXPORT
#else
#  ifndef geomodel_core_api
#    ifdef geomodel_core_EXPORTS
        /* We are building this library */
#      define geomodel_core_api __declspec(dllexport)
#    else
        /* We are using this library */
#      define geomodel_core_api __declspec(dllimport)
#    endif
#  endif

#  ifndef GEOMODEL_CORE_NO_EXPORT
#    define GEOMODEL_CORE_NO_EXPORT 
#  endif
#endif

#ifndef GEOMODEL_CORE_DEPRECATED
#  define GEOMODEL_CORE_DEPRECATED __declspec(deprecated)
#endif

#ifndef GEOMODEL_CORE_DEPRECATED_EXPORT
#  define GEOMODEL_CORE_DEPRECATED_EXPORT geomodel_core_api GEOMODEL_CORE_DEPRECATED
#endif

#ifndef GEOMODEL_CORE_DEPRECATED_NO_EXPORT
#  define GEOMODEL_CORE_DEPRECATED_NO_EXPORT GEOMODEL_CORE_NO_EXPORT GEOMODEL_CORE_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef GEOMODEL_CORE_NO_DEPRECATED
#    define GEOMODEL_CORE_NO_DEPRECATED
#  endif
#endif

#endif
