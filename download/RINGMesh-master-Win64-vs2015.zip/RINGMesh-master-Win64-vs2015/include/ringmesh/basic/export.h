
#ifndef basic_api_H
#define basic_api_H

#ifdef BASIC_STATIC_DEFINE
#  define basic_api
#  define BASIC_NO_EXPORT
#else
#  ifndef basic_api
#    ifdef basic_EXPORTS
        /* We are building this library */
#      define basic_api __declspec(dllexport)
#    else
        /* We are using this library */
#      define basic_api __declspec(dllimport)
#    endif
#  endif

#  ifndef BASIC_NO_EXPORT
#    define BASIC_NO_EXPORT 
#  endif
#endif

#ifndef BASIC_DEPRECATED
#  define BASIC_DEPRECATED __declspec(deprecated)
#endif

#ifndef BASIC_DEPRECATED_EXPORT
#  define BASIC_DEPRECATED_EXPORT basic_api BASIC_DEPRECATED
#endif

#ifndef BASIC_DEPRECATED_NO_EXPORT
#  define BASIC_DEPRECATED_NO_EXPORT BASIC_NO_EXPORT BASIC_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef BASIC_NO_DEPRECATED
#    define BASIC_NO_DEPRECATED
#  endif
#endif

#endif /* basic_api_H */
