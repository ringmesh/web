

namespace GLUP {
    void register_embedded_shaders_GLUP();
    void register_embedded_shaders_fullscreen();    
}
