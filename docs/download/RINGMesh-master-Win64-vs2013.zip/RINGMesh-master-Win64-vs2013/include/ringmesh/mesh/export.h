
#ifndef mesh_api_H
#define mesh_api_H

#ifdef MESH_STATIC_DEFINE
#  define mesh_api
#  define MESH_NO_EXPORT
#else
#  ifndef mesh_api
#    ifdef mesh_EXPORTS
        /* We are building this library */
#      define mesh_api __declspec(dllexport)
#    else
        /* We are using this library */
#      define mesh_api __declspec(dllimport)
#    endif
#  endif

#  ifndef MESH_NO_EXPORT
#    define MESH_NO_EXPORT 
#  endif
#endif

#ifndef MESH_DEPRECATED
#  define MESH_DEPRECATED __declspec(deprecated)
#endif

#ifndef MESH_DEPRECATED_EXPORT
#  define MESH_DEPRECATED_EXPORT mesh_api MESH_DEPRECATED
#endif

#ifndef MESH_DEPRECATED_NO_EXPORT
#  define MESH_DEPRECATED_NO_EXPORT MESH_NO_EXPORT MESH_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef MESH_NO_DEPRECATED
#    define MESH_NO_DEPRECATED
#  endif
#endif

#endif /* mesh_api_H */
