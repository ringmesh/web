
#ifndef geomodel_builder_api_H
#define geomodel_builder_api_H

#ifdef GEOMODEL_BUILDER_STATIC_DEFINE
#  define geomodel_builder_api
#  define GEOMODEL_BUILDER_NO_EXPORT
#else
#  ifndef geomodel_builder_api
#    ifdef geomodel_builder_EXPORTS
        /* We are building this library */
#      define geomodel_builder_api __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define geomodel_builder_api __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef GEOMODEL_BUILDER_NO_EXPORT
#    define GEOMODEL_BUILDER_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef GEOMODEL_BUILDER_DEPRECATED
#  define GEOMODEL_BUILDER_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef GEOMODEL_BUILDER_DEPRECATED_EXPORT
#  define GEOMODEL_BUILDER_DEPRECATED_EXPORT geomodel_builder_api GEOMODEL_BUILDER_DEPRECATED
#endif

#ifndef GEOMODEL_BUILDER_DEPRECATED_NO_EXPORT
#  define GEOMODEL_BUILDER_DEPRECATED_NO_EXPORT GEOMODEL_BUILDER_NO_EXPORT GEOMODEL_BUILDER_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef GEOMODEL_BUILDER_NO_DEPRECATED
#    define GEOMODEL_BUILDER_NO_DEPRECATED
#  endif
#endif

#endif /* geomodel_builder_api_H */
